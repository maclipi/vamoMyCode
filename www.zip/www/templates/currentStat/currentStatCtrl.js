angular.module('starter.controllers')

.controller('currentStatCtrl', function($scope){

console.log("On Current Status Page");
})
