angular.module('starter.controllers')

.controller('consolidSiteLocCtrl', function($scope){


})
