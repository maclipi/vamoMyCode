angular.module('starter.controllers')

.controller('consolidStopCtrl', function($scope){


})
