angular.module('starter.controllers')


.controller('multiplesiteCtrl',function($scope){

    console.log("On multiple Site Page");
})
