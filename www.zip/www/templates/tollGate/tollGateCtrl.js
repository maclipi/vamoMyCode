angular.module('starter.controllers')

.controller('tollGateCtrl', function($scope){


})
