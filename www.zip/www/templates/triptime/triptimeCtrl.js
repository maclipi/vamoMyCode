angular.module('starter.controllers')


.controller('triptimeCtrl',function($scope){

    console.log("On Trip Time Page");
})
