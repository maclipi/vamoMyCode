angular.module('starter.controllers')


.controller('sitetripCtrl',function($scope){

    console.log("On site Trip Page");
})
