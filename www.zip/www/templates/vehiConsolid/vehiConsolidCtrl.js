angular.module('starter.controllers')

.controller('vehiConsolidCtrl', function($scope){


})
