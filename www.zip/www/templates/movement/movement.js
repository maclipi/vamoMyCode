angular.module('starter.controllers')

.controller('movementCtrl', function(){


})
