angular.module('starter.controllers')


.controller('historyCtrl',function($scope){

    console.log("On History Page");
})
