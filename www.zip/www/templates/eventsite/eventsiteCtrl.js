angular.module('starter.controllers')


.controller('eventsiteCtrl',function($scope){

    console.log("On Event Site Page");
})
