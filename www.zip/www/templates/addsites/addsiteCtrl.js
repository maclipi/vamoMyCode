angular.module('starter.controllers')

.controller('addsiteCtrl', function($scope){


})
