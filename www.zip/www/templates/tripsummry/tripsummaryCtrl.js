angular.module('starter.controllers')


.controller('tripsummaryCtrl',function($scope){

    console.log("On trip Summary Page");
})
