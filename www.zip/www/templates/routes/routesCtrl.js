angular.module('starter.controllers')

.controller('routesCtrl', function(){


})
