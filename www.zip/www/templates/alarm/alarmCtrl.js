angular.module('starter.controllers')


.controller('alarmCtrl',function($scope){

    console.log("On Alarm Page");
})
