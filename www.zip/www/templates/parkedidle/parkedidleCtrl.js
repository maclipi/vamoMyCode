angular.module('starter.controllers')


.controller('parkedidleCtrl',function($scope){

    console.log("On Parked idle Page");
})
