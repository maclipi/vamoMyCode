angular.module('starter.controllers')


.controller('acstoppageCtrl',function($scope){

    console.log("On Account Stopage Page");
})
