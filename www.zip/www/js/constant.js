angular.module('starter')


.constant('CONSTANTS', {

    something: 12,
    baseUrl: "http://188.166.244.126:9000"  // production

    // baseUrl: "http://128.199.159.130:9000"   // sit
});
